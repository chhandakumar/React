import React, { Component } from 'react';
import FirstComponent  from './Components/Learning-examples/FirstComponent';
import Counter from './Components/Counter/Counter.js';

import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
       <Counter by={4}/>
      </div>
    );
  }
}


function SecondComponent (){
  return (
    <div className="App">
    function--SecondComponent
   </div>
  );
}


export default App;