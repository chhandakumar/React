import React, { Component } from 'react';

class FirstComponent extends Component {
    render() {
      return (
        <div className="App">
        class--FirstComponent
        </div>
      );
    }
  }

  export default FirstComponent;
  